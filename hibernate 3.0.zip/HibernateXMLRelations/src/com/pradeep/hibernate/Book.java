package com.pradeep.hibernate;
import java.util.HashSet;
import java.util.Set;
public class Book {
	private int id;
	private String bookName;
	private Set <Author>authors;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public Set getAuthors() {
		return authors;
	}
	public void setAuthors(Set authors) {
		this.authors = authors;
	}
	public String toString(){
		return bookName;
	}
}
